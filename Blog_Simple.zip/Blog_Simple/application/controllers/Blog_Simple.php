<?php

/**
 * 
 * 
 */
class Blog_Simple extends MY_Controller
{
	
	function __construct()
	{
		parent::__construct();
	}

public function index()
{
  $data['article'] = $this->Model->maRequete(" SELECT * FROM articles");
  
	$this->load->view('blog_view',$data);
}

public function add()
{
    $data['title']="Ajouter un article";
    $this->load->view('add_article_view',$data);
}

public function upload_file($nom_file,$nom_champ)
{
      $ref_folder =FCPATH.'upload_art';
      $code=date("YmdHis").uniqid();
      $fichier=basename($code);
      $file_extension = pathinfo($nom_champ, PATHINFO_EXTENSION);
      $file_extension = strtolower($file_extension);
      // $valid_ext = array('gif','jpg','png','jpeg','JPG','PNG','JPEG');

      if(!is_dir($ref_folder)) //create the folder if it does not already exists   
      {
          mkdir($ref_folder,0777,TRUE);
                                                     
      } 
      move_uploaded_file($nom_file, "$ref_folder/$fichier.$file_extension");
      $image_name=$fichier.".".$file_extension;
      return $image_name;
}

public function add_article()
	{
        $title=$this->input->post('title');
        $description=$this->input->post('description');
        $details=$this->input->post('details');

        $image=$this->upload_file($_FILES['file_name']['tmp_name'],$_FILES['file_name']['name']);
        

    	    


    	$insert=$this->db->query("INSERT INTO articles(photo_article,title_article,desc_article,corps_article) values('".$image."','".$title."','".$description."','".$details."')");
    	$data['sms']='<div class="alert alert-success text-center" id ="message">L\'article a été inseré avec succes.</div>';
        $this->session->set_flashdata($data);
        redirect(base_url('Blog_Simple/liste_article'));
	   
	       $data['sms']='<div class="alert alert-danger text-center" id ="message">Vérifiez votre image.</div>';
        $this->session->set_flashdata($data);
        redirect(base_url('Blog_Simple/liste_article'));
	    
}

public function getOne($id)
{
    $data['title']="Modification d'un article";
    $data['art_One']=$this->Model->maRequeteOne(" SELECT * FROM articles WHERE id_article=".$id."");
    $this->load->view('update_article_view',$data);
}

public function update_article()
{
        
        $id=$this->input->post('id');
        $title=$this->input->post('title');
        $description=$this->input->post('description');
        $details=$this->input->post('details');

        $image=$this->upload_file($_FILES['file_name']['tmp_name'],$_FILES['file_name']['name']);

            


        $update=$this->db->query("UPDATE articles SET photo_article='".$image."',title_article='".$title."',desc_article='".$description."',corps_article='".$details."' WHERE id_article=".$id."");
        $data['sms']='<div class="alert alert-success text-center" id ="message">L\'article a été modifié avec succes.</div>';
        $this->session->set_flashdata($data);
        redirect(base_url('Blog_Simple/liste_article'));
      

        $data['sms']='<div class="alert alert-danger text-center" id ="message">Vérifiez votre image.</div>';
        $this->session->set_flashdata($data);
        redirect(base_url('Blog_Simple/liste_article'));
        


}


 public function detail_article($id){

  
  $data['article']=$this->Model->maRequete(" SELECT * FROM articles WHERE id_article=".$id."");
  $data['articles']=$this->Model->maRequete(" SELECT * FROM articles");
  $this->load->view('detail_article_view',$data);
  }

public function liste_article(){
  $article=$this->Model->maRequete(" SELECT * FROM articles ");

    $data = array();
      foreach ($article as $row) 
      {
        $data_array = array(); 
        $data_array[]='<a class="venobox" target="_blanck" data-gall="myGallery" href="'.base_url('upload_art/').$row['photo_article'].'">
                <img style="height: 40px;width: 40px;" src="'.base_url('upload_art/').$row['photo_article'].'" alt="image alt"/>';
        $data_array[]=$row['title_article'];
        $data_array[]=$row['desc_article'];
        $data_array[]=$row['corps_article'];
        

        $data_array[]='<!-- Single button -->
                <div class="btn-group">
                  <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    OPTIONS <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu">
                  <li><a href="'.base_url('Blog_Simple/getOne/').$row['id_article'].'">Modifier</a></li>
                  <li><a href="#" data-toggle="modal" data-target="#delete'.$row['id_article'].'"><font color="red">Supprimer</font></a></li>
                  </ul>
                </div>

              <div class="modal fade" id="delete'.$row['id_article'].'">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                      <h4 class="modal-title text-center">Supprimer un article</h4>
                    </div>
                    <div class="modal-body">
                      <p>Voulez-vous supprimer article: <b style="color:green">'.$row['title_article'].'</b> ?</p>
                    </div>
                    <form action="'.base_url('Blog_Simple/delete').'" method="post">
                      <div class="modal-footer">
                        <input type="hidden" name="id_article" value="'.$row['id_article'].'">
                        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Annuler</button>
                        <input type="submit" name="submit" class="btn btn-danger" value="Supprimer">
                    </div>
                    </form>
                    
                  </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
              </div><!-- /.modal -->';
          

         
        $data[] = $data_array;
      }

     $data['ntirampeba'] = $data;
     $data['title']="Liste des articles";
      $template = array(
          'table_open' => '<table id="mytable" class="table table-bordered table-stripped table-hover table-condensed">',
          'table_close' => '</table>'
      );
        
      $this->table->set_heading('PHOTO','TITRE','DESCRIPTION','CORPS','OPTIONS');
       
      $this->table->set_template($template);

  $this->load->view('liste_blog_view',$data);
}

public function delete()
{
    $id=$this->input->post('id_article');
    $delete=$this->db->query("DELETE FROM articles WHERE id_article=".$id."");
    $data['sms']='<div class="alert alert-danger text-center" id ="message">Suppression fait avec succes.</div>';
    $this->session->set_flashdata($data);
    redirect(base_url('Blog_Simple/liste_article'));


}

function comment(){
    
    $this->load->view('comment_view');
}

function like(){
    $this->load->view('like_view');
}

public function add_like(){
  $id=1;

    $id_article=$this->input->post('id_article');
    $user=$this->input->post('email');

    $verif=$this->Model->maRequeteOne("SELECT * FROM likes WHERE email='".$user."' and id_article=".$id_article."");
    $like_number=$this->Model->maRequeteOne("SELECT * FROM likes WHERE id_article=".$id_article."");
    if (!empty($like_number)) {
      $like_number=$like_number['like_number']+1;
    } else {
      $like_number=1;
    }
    
    

    if (empty($verif)) {

      $this->db->query("INSERT INTO likes(like_number,id_article,email) values('".$like_number."','".$id_article."','".$user."')");

      redirect(base_url('Blog_Simple/index'));
    }
    else{
      $data['sms']='<div class="alert alert-danger text-center" id ="message">vous ne pouvez pas aimer plus d\'une fois un même article.</div>';

      $this->session->set_flashdata($data);
      redirect(base_url('Blog_Simple/index'));
    }
  }

  public function add_comment(){
  $id=1;

    $id_article=$this->input->post('id_article');
    $user=$this->input->post('email');
    $comment=$this->input->post('commentaire');

    $verif=$this->Model->maRequeteOne("SELECT count(id_article) as nb, email FROM comments WHERE email='".$user."' AND id_article='".$id_article."'");
    

    if ($verif['nb']<3) {

      $this->db->query("INSERT INTO comments(email,comment,id_article) values('".$user."','".$comment."','".$id_article."')");

      $data['sms']='<div class="alert alert-success text-center" id ="message">L\'enregistrement reussi avec succes.</div>';

      $this->session->set_flashdata($data);
      redirect(base_url('Blog_Simple/index'));
    }
    else{
      $data['sms']='<div class="alert alert-success text-center" id ="messageCX">vous ne pouvez pas commenter plus de 3 fois le mËme article.</div>';

      $this->session->set_flashdata($data);
      redirect(base_url('Blog_Simple/index'));
    }
  }

}
