<?php
/**
 * 
 */
class Model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	function maRequete($requete)
	{
      $query=$this->db->query($requete);
      if ($query) {
         return $query->result_array();
      }
    }
    function maRequeteOne($requete)
	{
      $query=$this->db->query($requete);
      if ($query) {
         return $query->row_array();
      }
    }
}