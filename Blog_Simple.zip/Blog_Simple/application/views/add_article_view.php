<!DOCTYPE html>
<html lang="en">

<head>
<?php include VIEWPATH.'includes/header.php' ?>
</head>
<body>
    <div class="container-fluid" style="background-color: white">
        
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12" style=" margin-bottom: 5px">
                            
                            <div class="row" id="conta" style="margin-top: -10px">
                                 <div class="col-lg-6 col-md-6">                                  
                                   <h4><b><?=$title?></b>
                                    <a href="<?= base_url('/Blog_Simple/liste_article')?> " class="btn btn-primary  pull-right"><i class="fa fa-plus"></i> Liste</a>
                                   </h4>  
                                </div>
                               
                            </div>  
                        </div> 
                  <div class="col-lg-12 jumbotron" style="padding: 5px">
                      <form action="<?= base_url('Blog_Simple/add_article')?>" method="post" enctype="multipart/form-data">
                        <div class="row">
                          <div class="col-md-4">
                            <label>Image</label>
                              <input type="file" class="form-control" name="file_name" placeholder="Image....." required="" />
                                         
                          </div>
                          <div class="col-md-4">
                            <label>Title</label>
                               <input type="text" class="form-control" name="title" placeholder="Title....." required=""/>
                                       
                          </div>
                          <div class="col-md-4">
                            <label>Description</label>
                               <input type="text" class="form-control" name="description" placeholder="Description....." required=""/>
                                       
                          </div>
                          <div class="form-group col-md-6">
                            <label>Détail</label>
                            <textarea  class="form-control" name="details" rows="1" required="">
                              
                            </textarea>               
                                       
                          </div>



                         
                          <div class="col-md-2">
                            <label></label><br>
                            <input type="submit" class="btn btn-primary form-control" value="Enregistrer">
                          </div>
                          </div>
                          
                           
                      </form>     
                 </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            
</body>

</html>


