<!DOCTYPE html>
<html lang="en">

<head>
 <?php
  include VIEWPATH.'includes/header_front.php'
 ?>
 <style type="text/css">
   .animated {
    -webkit-transition: height 0.2s;
    -moz-transition: height 0.2s;
    transition: height 0.2s;
  }

  .stars
  {
    margin: 20px 0;
    font-size: 24px;
    color: #d49e22;
  }
  .stars:hover,
  .stars:focus {
    color: #024252;
    text-decoration: none;
    cursor: pointer;
  }



</style>
<style type="text/css">

  input[type=checkbox] {
   /*transform: scale(1.5);*/
 }

 input[type=radio] {
  width: 20px;
  height: 20px;
}
</style>

</head>
<body>
<section class="pub">
  <div>
    <h2 class="text-center">MON BLOG SIMPLE</h2>
    <hr id="ligne">
  </div>
</section>

<?php
    if($this->session->flashdata('sms'))
        echo $this->session->flashdata('sms');
 ?>
<section id="publicite">
  <div class="container-fluid">
    <div class="row">

  <div class="bs-docs-example">
        <ul id="myTab" class="nav nav-tabs" id="nav-tabs" style="margin-left: 70px;">
          <li class="active"><a href="#" data-toggle="tab">Accueil</a></li>
          <li><a href="<?= base_url('Blog_Simple/liste_article')?>" data-toggle="tab">Liste des articles</a></li>
          
        </ul>
        <div id="myTabContent" class="tab-content">
        <div class="tab-pane fade in active" id="home">

  <div class="col-md-12">
<?php 
         foreach ($article as $value) {             ?>
    <div class="col-md-4">
       <div class="card">
        <img src="<?=base_url('upload_art/').$value['photo_article'];?>" alt="">
        <div class="card-body">
          <h4 class="card-title text-center"><?= $value['title_article'];?></h4>
          <p class="card-text"><?= $value['desc_article'];?></p>
        </div>
        <div class="card-footer">
          <ul class="pager">
            <li class="next pull-left">
              <a href="<?= base_url('Blog_Simple/detail_article/').$value['id_article'];?>">Plus &rarr;
                </a>
                <a href="<?= base_url('Blog_Simple/like/').$value['id_article'];?>"  title="Aimer">
                  <i class="fa fa-thumbs-up" aria-hidden="true" ></i>
                  <?php
                $data=$this->Model->maRequeteOne("SELECT COUNT(like_number) AS total FROM likes WHERE id_article=".$value['id_article']."");
              echo number_format($data['total']) ?>
                                        
                </a>
                <a href="<?= base_url('Blog_Simple/comment/').$value['id_article'];?>"title="Commentaire" title="Commentaire"><i class="fa fa-comment" aria-hidden="true" ></i><?php
                $data=$this->Model->maRequeteOne("SELECT count(*) as total FROM comments WHERE id_article=".$value['id_article']."");
              echo number_format($data['total']) ?>
            </a><br>
            </li>
          </ul>
        </div>
       </div>
    </div>

<?php } ?>

</div>

  </div>
 
     
      </div>      
    </div>


  </div>
  </div>
</div>
  </div>
</section>
</body>
</html>



<script>
$(document).ready(function(){ 
    $('#message').delay(5000).hide('slow');
    });

// 
</script>
