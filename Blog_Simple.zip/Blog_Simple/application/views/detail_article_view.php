<!DOCTYPE html>
<html lang="en">

<head>
 <?php
  include VIEWPATH.'includes/header_front.php'
 ?>
 <style type="text/css">
   .animated {
    -webkit-transition: height 0.2s;
    -moz-transition: height 0.2s;
    transition: height 0.2s;
  }

  .stars
  {
    margin: 20px 0;
    font-size: 24px;
    color: #d49e22;
  }
  .stars:hover,
  .stars:focus {
    color: #024252;
    text-decoration: none;
    cursor: pointer;
  }


</style>
<style type="text/css">

  input[type=checkbox] {
   /*transform: scale(1.5);*/
 }

 input[type=radio] {
  width: 20px;
  height: 20px;
}
</style>

</head>
<body>
<section id="detail">
  <div class="container-fluid">
   <div class="row">
<?php      foreach ($article as $value) {  ?>


  		<div class="col-md-5">
  		   <img src="<?=base_url('upload_art/').$value['photo_article'];?>" alt="">
  		</div>
  		<div class="col-md-7">
   	  	  <h4 class="text-center"><?= $value['title_article'];?> </h4><hr>
        
        <p><?= $value['corps_article'];?></p>
      </div>
                
             
              </div>
            </div> 
          </div>
   	  	</div>
<?php } ?>
   	</div>
</div>
</section>

<div>
    <h2 class="text-center">Les autres articles</h2>
    <hr id="ligne">
  </div>

<section id="publicite">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">


<?php 
         foreach ($articles as $all) { 

if ($all['id_article']!=$value['id_article']) { ?>
    <div class="col-md-4">
       <div class="card">
        <img src="<?=base_url('upload_art/').$all['photo_article'];?>" alt="">
        <div class="card-body">
          <h4 class="card-title text-center"><?= $all['title_article'];?></h4>
          <p class="card-text"><?= $all['desc_article'];?></p>
        </div>
        <div class="card-footer">
          <ul class="pager">
            <li class="next pull-left">
              <a href="<?= base_url('Blog_Simple/detail_article/').$all['id_article'];?>">Plus &rarr;
                </a>
                <a href="<?= base_url('Blog_Simple/like/').$all['id_article'];?>">
                  <i class="fa fa-thumbs-up" aria-hidden="true"></i>
                  <?php
                $data=$this->Model->maRequeteOne("SELECT COUNT(like_number) AS total FROM likes WHERE id_article=".$all['id_article']."");
              echo number_format($data['total']) ?>
                                        
                </a>
                <a href="<?= base_url('Blog_Simple/comment/').$all['id_article'];?>"><i class="fa fa-comment" aria-hidden="true"></i><?php
                $data=$this->Model->maRequeteOne("SELECT count(*) as nb FROM comments WHERE id_article=".$all['id_article']."");
              echo number_format($data['nb']) ?>
                </a><br>
            </li>
          </ul>
        </div>
       </div>
    </div>

<?php } } ?>

    </div>
  </div>
</section>
</body>
</html>


