 <!-- Basic -->
    <meta charset="UTF-8">

    <title>BLOG</title>
    <meta name="keywords" content="HTML5 Admin Template" />
    <meta name="description" content="Porto Admin - Responsive HTML5 Template">
    <meta name="author" content="okler.net">

    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
 
    <!-- Web Fonts  -->
    <link href="<?php echo base_url() ?>Design/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url() ?>Design/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url() ?>Design/dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="<?php echo base_url() ?>assets/datepicker/css/datepicker.css" rel="stylesheet">
      <link href="<?php echo base_url() ?>assets/datepicker/css/jquery.datetimepicker.min.css" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="<?php echo base_url() ?>Design/vendor/morrisjs/morris.css" rel="stylesheet">
    <!-- Custom Fonts -->
    <link href="<?php echo base_url() ?>Design/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/datatable/button.datatables.min.css">

    <script src="<?php echo base_url() ?>Design/vendor/jquery/jquery.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datatable/datatables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datepicker/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datepicker/js/jquery.datetimepicker.full.js"></script>


    <!-- Bootstrap Core JavaScript -->
    <script src="<?php echo base_url() ?>Design/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!-- Metis Menu Plugin JavaScript -->
    <script src="<?php echo base_url() ?>Design/vendor/metisMenu/metisMenu.min.js"></script>
    <script src="<?php echo base_url() ?>Design/dist/js/sb-admin-2.js"></script>


     <link rel="stylesheet" href="<?php echo base_url()  ?>leaflet/dist/leaflet.css" />
     <script type="text/javascript" src="<?php echo base_url() ?>leaflet/dist/leaflet.js"></script>

    <script src="<?php echo base_url() ?>leaflet/boucing/leaflet.smoothmarkerbouncing.js"></script>

    <script src="<?php echo base_url() ?>assets/validation/dist/jquery.validate.js" rel="stylesheet"></script>
    <script src="<?php echo base_url() ?>assets/validation/dist/additional-methods.js" rel="stylesheet"></script>
