    <meta charset="UTF-8">
    <title>BLOG SIMPLE</title>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">  
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>front/css/master.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>front/css/color-green.css">
    <link rel="shortcut icon" href="<?php echo base_url() ?>front/images/short_icon.png">
    

    
    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>Design/datepicker/css/daterangepicker.css">

