
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
  
    <title>BLOG SIMPLE</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url() ?>Design/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- MetisMenu CSS -->
    <link href="<?php echo base_url() ?>Design/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url() ?>Design/dist/css/sb-admin-2.css" rel="stylesheet">

    <link href="<?php echo base_url() ?>assets/datepicker/css/datepicker.css" rel="stylesheet">

    <link href="<?php echo base_url() ?>assets/datepicker/css/jquery.datetimepicker.min.css" rel="stylesheet">

    <!-- Morris Charts CSS -->
    <link href="<?php echo base_url() ?>Design/vendor/morrisjs/morris.css" rel="stylesheet">
    <!-- Custom Fonts -->

    <link href="<?php echo base_url() ?>Design/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/datatable/datatables.min.css">

    <script type="text/javascript" src="<?php echo base_url() ?>assets/datatable/datatables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datepicker/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/datepicker/js/jquery.datetimepicker.full.js"></script>

  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/csss/jquery.jOrgChart.css">
  <link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url() ?>assets/css/bootstrap.css" rel="stylesheet">
   
        <script src="<?php echo base_url() ?>assets/js/jquery.jOrgChart.js"></script>

    <script src="<?php echo base_url() ?>Design/vendor/bootstrap/js/bootstrap.min.js"></script>

    <script src="<?php echo base_url() ?>Design/vendor/metisMenu/metisMenu.min.js"></script>

    <script src="<?php echo base_url() ?>Design/dist/js/sb-admin-2.js"></script>



<!-- Summernote -->
<script src="<?= base_url()?>assets/summernote/summernote-bs4.min.js"></script>

<link rel="stylesheet" href="<?php echo base_url() ?>MultiSelect/css/bootstrap-multiselect.css"/>
<script src="<?php echo base_url() ?>MultiSelect/js/bootstrap-multiselect.js"></script>
<script src="<?php echo base_url() ?>assets/validation/dist/jquery.validate.js" rel="stylesheet"></script>
<script src="<?php echo base_url() ?>assets/validation/dist/additional-methods.js" rel="stylesheet"></script>