<!DOCTYPE html>
<html lang="en">

<head>
  <?php include VIEWPATH.'includes/header.php' ?>
</head>
<body>


  <?php 

  $id_article=$this->uri->segment(3);
   ?>
  <div class="container-fluid" style="background-color: white">

    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12" styl
        e=" margin-bottom: 5px">
        <div class="row" style="" id="conta">
         
        </div>
        <div class="row" id="conta" style="margin-top: -10px">
         <div class="col-lg-6 col-md-6"> 
          
           
         </div>
         <div class="col-lg-6 col-md-6" style="padding-bottom: 3px">
          
         </div>
       </div>  
     </div> 
     <div class="col-lg-12 jumbotron" style="padding: 5px">
      <?= $this->session->flashdata('sms') ?> 
      <form method="POST" action="<?=base_url().'Blog_Simple/add_like'?>">
        
        
       
        
        <div class="form-group col-md-6">
          <label>Email</label>
           <input type="hidden" class="form-control" name="id_article" value="<?= $id_article ?>"> 
          <input type="text" class="form-control" name="email" required=""> 
                        
        </div>  
        

        <div class=" col-md-12">
         <input type="submit" class="btn btn-primary" value="Valider" >
       </div>
     </div>
     
   </form>
 </div>
 
</div>

</div>

</body>

</html>
<script>

  $(document).ready(function(){
    $('#message').delay(2000).hide('slow');

  });
</script>