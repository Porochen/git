<!DOCTYPE html>
<html lang="en">

<head>
<?php include VIEWPATH.'includes/header.php' ?>
</head>
<body>
    <div class="container-fluid" style="background-color: white">
        
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12" style=" margin-bottom: 5px">
                            
                            <div class="row" id="conta" style="margin-top: -10px">
                                 <div class="col-lg-6 col-md-6">                                  
                                   <h4><b><?=$title?></b>
                                    <a href="<?= base_url('Blog_Simple/liste_article')?> " class="btn btn-primary  pull-right"><i class="fa fa-plus"></i> Liste</a>
                                   </h4>  
                                </div>
                               
                            </div>  
                        </div> 
                  <div class="col-lg-12 jumbotron" style="padding: 5px">
                      <form action="<?= base_url('Blog_Simple/update_article')?>" method="post" enctype="multipart/form-data">
                        <div class="row">
                          <input type="hidden" class="form-control" name="id" value="<?=$art_One['id_article']?>" />
                          <div class="col-md-4">
                            <label>Image</label>
                              <input type="file" class="form-control" name="file_name" value="<?=$art_One['photo_article']?>" placeholder="Image....."/>
                            <font color='red'><?php echo form_error('file_name'); ?></font>             
                          </div>
                          <div class="col-md-4">
                            <label>Title</label>
                               <input type="text" class="form-control" name="title" value="<?=$art_One['title_article']?>" placeholder="Title....."/>
                            <font color='red'><?php echo form_error('title'); ?></font>             
                          </div>
                          <div class="col-md-4">
                            <label>Description</label>
                               <input type="text" class="form-control" name="description" value="<?=$art_One['desc_article']?>" placeholder="Description....."/>
                            <font color='red'><?php echo form_error('description'); ?></font>             
                          </div>
                          <div class="col-md-8">
                            <label>Détail</label>
                               <textarea class="textarea" name="details"  placeholder="Detail......" style="width: 100%; height: 125px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?=$art_One['corps_article']?></textarea>
                            <font color='red'><?php echo form_error('description'); ?></font>             
                          </div>
                         
                          <div class="col-md-4">
                            <label></label><br>
                            <input type="submit" class="btn btn-primary" value="Enregistrer">
                          </div>
                          </div>
                          
                           
                      </form>     
                 </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </div>
            
</body>

</html>
