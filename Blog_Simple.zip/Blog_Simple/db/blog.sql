-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  ven. 14 mai 2021 à 23:28
-- Version du serveur :  10.1.37-MariaDB
-- Version de PHP :  7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `blog`
--

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id_article` int(11) NOT NULL,
  `photo_article` varchar(200) NOT NULL,
  `title_article` varchar(100) NOT NULL,
  `desc_article` varchar(200) NOT NULL,
  `corps_article` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `articles`
--

INSERT INTO `articles` (`id_article`, `photo_article`, `title_article`, `desc_article`, `corps_article`) VALUES
(1, 'ONATEL.jpg', 'Onatel', 'Profite bien de ce jour ou tout t\'est permis,', 'Profite bien de ce jour ou tout t\'est permis, ou presque... Heureux anniversaire ! Aujourd\'hui est un jour doublement important : celui où l\'on te souhaite un joyeux anniversaire, et celui où l\'on te rappelle par ces quelques mots que tu es une personne importante à nos yeux. Heureux anniversaire'),
(3, '20210513230127609d93a7ac144.jpg', 'MON PROFILE', 'JUSTE TO SHOW YOU MY PROFILE', 'HAHAHAHAHAHA REKA KUNTWENZA'),
(4, '20210513231040609d95d08296a.jpg', 'MON PROFILE', 'CHARGE DE LA CARTE', 'HELLO'),
(10, '20210513230006609d9356aa2a6.jpg', 'MON PROFILE', 'CHARGE DE LA CARTE', 'sdfguilk,hjuio'),
(11, 'ONATEL1.jpg', 'MON POTE', 'TU ES OU MON AMI', 'Some characters are reserved in HTML.\r\n\r\nIf you use the less than (<) or greater than (>) signs in your text, the browser might mix them with tags.\r\n\r\nCharacter entities are used to display reserved characters in HTML.')

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id_comment` int(11) NOT NULL,
  `comment` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `id_article` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`id_comment`, `comment`, `email`, `id_article`) VALUES
(1, '            \r\n          ', 'jeandedieuntirampeba@gmail.com', 0),
(2, '       hahaha     \r\n          ', 'jeandedieuntirampeba@gmail.com', 3),
(3, '         i like this pucture  \r\n          ', 'olivier@gmail.com', 3),
(4, '            hahaha\r\n          ', 'uyc.tic@gmail.com', 4);

-- --------------------------------------------------------

--
-- Structure de la table `likes`
--

CREATE TABLE `likes` (
  `id_like` int(11) NOT NULL,
  `like_number` int(11) NOT NULL,
  `id_article` int(11) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `likes`
--

INSERT INTO `likes` (`id_like`, `like_number`, `id_article`, `email`) VALUES
(1, 1, 3, 'olivier@gmail.com'),
(2, 1, 4, 'jeandedieuntirampeba@gmail.com'),
(3, 2, 3, 'uyc.tic@gmail.com'),
(4, 2, 3, 'jeandedieuntirampeba@gmail.com');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`) VALUES
(1, 'admin@blog.com', '92f96e5e5529ceec6218be1b9f909f85');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id_article`);

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id_comment`);

--
-- Index pour la table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id_like`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `articles`
--
ALTER TABLE `articles`
  MODIFY `id_article` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id_comment` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `likes`
--
ALTER TABLE `likes`
  MODIFY `id_like` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
