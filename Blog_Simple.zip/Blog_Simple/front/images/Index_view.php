<!DOCTYPE html>
<html lang="en">

<head>
       <?php
       include 'includes/header_front.php';
        ?>
<style type="text/css">
   .animated {
    -webkit-transition: height 0.2s;
    -moz-transition: height 0.2s;
    transition: height 0.2s;
}

.stars
{
    margin: 20px 0;
    font-size: 24px;
    color: #d49e22;
}
 .stars:hover,
 .stars:focus {
  color: #024252;
  text-decoration: none;
  cursor: pointer;
}
</style>
</head>

<body>

    <!-- HEADER --><!-- LOADER -->
        <?php
        $home='active';
        $resto='';
        $categorie='';
        $contact='';
        $map='';
        include 'includes/menu_principal_front.php';
        ?>
    <!-- HEADER  --><!--LOADER-->

    <!-- Banner -->
       <?php
        include 'includes/banner_front.php';
        ?>
    <!-- Banner -->
 <!-- <div class="banner-icons">
      <ul>
          <li><a onclick="showresponddiv('pub')"><i class="glyphicon glyphicon-info-sign" style="size: 24px"></i></a> </li>
          
          <li><a onclick="showresponddiv('pub')"><i class="glyphicon glyphicon-eye-open"></i></a> </li>
        
      </ul>
  </div> -->
 <!-- Directory Category -->
    <section id="directory-category" class="p_b70 p_t70">
        <div class="container">
            <div class="row">
                <div class="col-md-12 directory-category-heading">
                    <h2> 

              <span>Les hôtels du Burundi</span></h2>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div id="directory-category-slider" class="owl-carousel owl-theme">
  <?php  
  $i=0; 
 foreach ($hotels as $resto) {
    $photo=$this->Model->getOne('photo_hotel',array('ID_HOTEL'=>$resto['HOTEL_ID'])); 
 $i++;
        ?>
                        <div class="item">
                            <div class="directory-category-box col-md-3" > 
         <a href="<?php echo base_url() ?>Home/detail/<?=$resto['HOTEL_ID']?>">   <img style="height:200px;" src="<?php echo base_url() ?><?=$photo['PATH_PHOTO']?>"  alt="Smiley" > </a>
                           <!--  </span> -->
                                <a href="<?php echo base_url() ?>Home/detail/<?=$resto['HOTEL_ID']?>">
                                    <h3 class="text"><?=$resto['ACCOMMODATION_NAME']?></h3>

                                </a>
                                <input value="<?=$resto['ACCOMMODATION_NAME']?>" type="hidden" name="" id="title_resto<?=$i?>" >
                                      <input value="<?php echo base_url() ?><?=$photo['PATH_PHOTO']?>"  type="hidden" name="" id="imgrc_resto<?=$i?>"  >
                                <p>

<table class="table"><tr class="btn-my"><td>
 <?php
$android = stripos($_SERVER['HTTP_USER_AGENT'], "android");
$iphone = stripos($_SERVER['HTTP_USER_AGENT'], "iphone");
$ipad = stripos($_SERVER['HTTP_USER_AGENT'], "ipad");

if($android !== false || $ipad !== false || $iphone !== false) {//For mobile
   ?>
   <ul><li><i class="fa fa-whatsapp" aria-hidden="true"></i> <a target="_blank" href="https://api.whatsapp.com/send?phone=257<?=$resto['TEL']?>"><font size="1px">Whatsapp</font> </a></li></ul>
   <?php
} else {//For desktop
   ?>
<a target="_blank" href="https://web.whatsapp.com/send?phone=257<?=$resto['TEL']?>"><i class="fa fa-whatsapp" aria-hidden="true"></i>  <font size="2px">Whatsapp</font></a>
   <?php
}
      ?></td>
<td><a  target="_blank" href="sms:257<?=$resto['TEL']?>"><i class="fa fa-commenting-o" aria-hidden="true"></i> SMS </a> </td>
<td><a target="_blank" href="tel:257<?=$resto['TEL']?>"><i class="fa fa-phone" aria-hidden="true"></i>  Call</a></td>

<tr><td colspan="3">
                                 
                                     </p><?php   
$tot=$this->Model->getRequeteOne("SELECT COUNT(*) as nb FROM rating_hotels WHERE HOTEL_ID=".$resto['HOTEL_ID']." ");
$like=$this->Model->getRequeteOne("SELECT COUNT(*) as nb FROM likes_hotels WHERE HOTEL_ID=".$resto['HOTEL_ID']." ");
$som=$this->Model->getRequeteOne("SELECT SUM(RATING) as nb FROM rating_hotels WHERE HOTEL_ID=".$resto['HOTEL_ID']." ");

$tag=$this->Model->getRequeteOne("SELECT COUNT(*)  as nb FROM rating_hotels");
if($tag['nb']>0){
$moy=$som['nb']/ (5 * $tag['nb']);
}else{
 $moy=0; 
}

?>
                               (<?=!empty($tot['nb'])?$tot['nb']:0?> Avis) <?php 

                                
                                  $values=$this->Model->getOne("rating_hotels",array('HOTEL_ID '=>$resto['HOTEL_ID']));
                                  $rate="";
                                  for ($j=1; $j <= 5; $j++) { 

                                    $class=$j<=$moy? "check" : "";
                                    $rate.='<a   onclick="add_rating_resto('.$i.','.$resto['HOTEL_ID'].')"> <span class="fa fa-star '.$class.'"   ></span></a>';
                                   } 
                                   echo $rate;

                                  ?>                             
                                
                                 <style type="text/css">.check {
                                      color: orange;
                                    }</style>&emsp; <a onclick="add_rating_resto('<?=$i?>','<?=$resto['HOTEL_ID']?>')"> <i class="fa fa-thumbs-o-up"><sup><span class="badge badge-warning checked" ><?=$like['nb']?></span></sup></td></tr></table></a>
                                            </div> 
                        </div>

        <?php  

    } ?>
                     


                        <!--  -->

                    </div>
                </div>
            </div>
        </div>
    </section>


<!-- Restaurant rating -->
<div id="alert_resto" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header btn-my">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
               <center><h3 class="modal-title" id="title_resto"></h3></center> 
            </div>
  
            <div class="modal-body row">
  <div class="col-md-12">
    <div class="well well-sm">
            <div class="text-right">
                <a class="btn btn-success btn-my" href="#reviews-anchor" id="open-review-resto">Laisser un avis</a>
            </div>
        
            <div class="row" id="post-review-resto" style="display:none;">
                   <form accept-charset="UTF-8" action="<?=base_url()?>Home/Add_Rating_Resto" method="post" id="myrate">
                       
                <div class="col-md-12">
                        <input id="ratings-hidden-resto" name="rating_resto"  type="hidden"> 
                        <input id="resto_id" name="RESTO_ID" type="hidden">
                        <div class="col-md-8">
                          <div class="stars starrr" id="star-resto" data-rating="0">Votre notation&emsp;&emsp;</div>
                         </div>
                         <div class="col-md-4 text-right"> <a class="btn btn-danger btn-sm" href="#" id="close-review-resto" style="display:none;">
                            <span class="glyphicon glyphicon-remove"></span></a></div>

                          <div class="row">
                        <div class="col-md-8">  <textarea class="form-control animated" cols="50" id="resto-review" name="comment" placeholder="Votre avis ici ..." rows="1" required=""></textarea></div>
                      
                         <div class=" col-sm-4">
                        
                        
                        <div class="text-right">                         
                           <?php if(!empty($this->session->userdata('USER_ID'))){  ?>
                            <button class="btn btn-my btn-lg" type="submit"  >Enregitrer</button>
                          <?php }else{?><button class="btn btn-my btn-lg" type="button"  onclick="info()" >Enregitrer</button><?php } ?>
                        </div>
                        </div></div>
                    
                </div>
                </form>
            </div>
        </div> 
         
   
  </div>            
<div class="col-md-6"><img id="resto_image" src=""></div>   
<div class="col-md-6">

        <h4>Répartition des notations</h4>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">5 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-success" role="progressbar" id="cinqr" aria-valuenow="5" aria-valuemin="0" aria-valuemax="5" style="width: 50%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
         <!--  <div class="pull-right" style="margin-left:10px;">1</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">4 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="5" id="quatrer" style="width: 80%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
          <!-- <div class="pull-right" style="margin-left:10px;">1</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">3 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="3" aria-valuemin="0" aria-valuemax="5" id="troisr" style="width: 60%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
         <!--  <div class="pull-right" style="margin-left:10px;">0</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">2 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="2" aria-valuemin="0" aria-valuemax="5" id="deuxr" style="width: 40%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
        <!--   <div class="pull-right" style="margin-left:10px;">0</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">1 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="5" id="unr" style="width: 20%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
          <!-- <div class="pull-right" style="margin-left:10px;">0</div> -->
        </div>
      </div>      
  
<div class="col-sm-6">
        <div class="rating-block">
          <h4>Note moyenne des utilisateurs</h4>
          <h2 class="bold padding-bottom-7"><font id="totalr"></font> <small>/ 5</small></h2>
         
          <!--  btn btn-warning btn-sm-->
          <button type="button" id="rstar1" class="btn-default btn-grey " aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button" id="rstar2" class=" btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button"id="rstar3"  class="btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button" id="rstar4" class="btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button" id="rstar5" class="btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button class="btn btn-my" onclick="do_like_resto($('#resto_id').val())"><font id="aimer">J'aime </font> <i class="fa fa-thumbs-o-up"></i></button>
     
        </div>
      </div>


</div>
  

<div class="modal-footer">
   <div class="pull-left" ><a onclick="resto($('#resto_id').val())" class="btn btn-my" > Faire une réselvation</a> </div>      <button type="button" class="btn btn-danger" data-dismiss="modal">x</button>
         </div>

            </div>
        </div>
    
</div>












    <!-- Popular Listing -->
    <section id="popular-listing" class="p_t70 over-hide-bottom">
        <div class="container" id="categorie">
            <div class="row">

                <div class="col-md-12 heading">
                    <h2>Listes des <span>hôtels</span></h2>
                </div>
            </div>
<input type="hidden" id="key_resto" value="<?=$this->session->userdata('HOTEL_ID')?>">            <div class="row">
                <div class="col-md-9 col-sm-9 col-xs-12 row">


                    <div class="sort-by">
           <div class="sort-category"> <span>Recherche</span>

             <div class="single-query form-group">
                                <div class="">
                                    <select id="ETOILE_ID" name="ETOILE_ID" class="form-text" onchange="serach_resto(this.value,0)">
                                        <option value="">par étoiles</option>
                                        <?php


 foreach ($etoiles as $etoi) {  ?>

  <option value="<?=$etoi['ETOILE_ID']?>"  <?=$etoi['ETOILE_ID']==set_value('ETOILE_ID') ? 'selected' :''?>><?=$etoi['DESCRIPTION']?></option>
   <?php }  ?>
                                      
                                       
                                    </select>
                                </div>
                            </div>
                            
                            <ul class="nav nav-tabs sort-listing" role="tablist">
                                <li role="presentation" class="active"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab"><i class="fa fa-th" aria-hidden="true"></i></a>
                                </li>
                               <!--  <li role="presentation"><a href="#home" aria-controls="home" role="tab" data-toggle="tab"><i class="fa fa-th-large" aria-hidden="true"></i></a>
                                </li> -->
                               <!--  <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab"><i class="fa fa-th-list" aria-hidden="true"></i></a>
                                </li> -->
                            </ul>
                        </div>
                    </div>










  <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade in active" id="profile">
                            <div class="row">

 <?php   $i=0;  
foreach ($all_hotels as $key ) {
$i++;
 $photo=$this->Model->getOne('photo_hotel',array('ID_HOTEL'=>$key['HOTEL_ID']));
 ?>
 <div class="col-md-4 col-sm-6 col-xs-12">
                                    <div class="popular-listing-box">
                                        <div class="popular-listing-img">
                                            <figure class="effect-ming" onclick="show_image('<?=$i?>','<?=$key['HOTEL_ID']?>','1')"> <img style="height:250px " src="<?php echo base_url() ?><?=$photo['PATH_PHOTO']?>" alt="image"></a><input value="<?php echo base_url() ?><?=$photo['PATH_PHOTO']?>" type="hidden" id="imgrcc<?=$i?>"  >
                                                <figcaption>
                                                    <ul>
                                                   
                                                        <li><a onclick="image('<?php echo base_url() ?><?=$photo['PATH_PHOTO']?>')"><i class="fa fa-eye"></i></a> </li>
                                                      
                                                    </ul>

                                                </figcaption>
                                            </figure>
                                        </div>
  <div class="popular-listing-detail">
   <a ><b> <?=$key['ACCOMMODATION_NAME']?></b></a><br>
     Nombre de chambres :<b> <?=$key['NUMBER_OF_BEDROOMS']?></b>
 <!--  <table class="table table-sm">
    <tr><th>Prix ​​de la chambre</th></tr>
   <tr><td>Petite :  <b><?=$key['SINGLE_ROOM_PRICE']?></b></td></tr>
  <tr><td>Moyenne :  <b><?=$key['AVERAGE_PRICE']?></b></td></tr> 
  <tr><td>Double :  <b><?=$key['DOUBLE_ROOM_PRICE']?></b></td></tr>   </table> --> 
</div>

                                        <div class="popular-listing-add" >
                                           <a   class="btn btn-my"  href="<?=base_url()?>Home/detail/<?=$key['HOTEL_ID']?>"> <i class="fa fa-hotel"></i>  &emsp;<i style="font-size: 24px" class="fa fa-eye"></i></a>
                                       </div> 
                                    </div>
                                </div>

                          <?php } ?>
                              
                            </div>
                        </div>

                        




 <div class="add-more text-center">
  <?= $links ?>
 <?=$message?>
       </div>







                    </div>
                </div>
                <div class="col-md-3 col-sm-3 col-xs-12" id="singup">

                    <div class="right-bar">
                        <h4>S'inscrire  pour reçevoir des notifications</h4>
                        <form id="mysingup" class="form-right" action="<?=base_url()?>Home/inscription" method="POST">
                            <div class="form-group">
                                <input type="text" autocomplete="false" class="form-control" placeholder="Nom" name="NOM" id="NOM" >
                                  <font color="red" id="error_nom"></font>
                            </div>
                            <div class="form-group">
                                <input type="text" autocomplete="false" class="form-control" placeholder="Prénom" name="PRENOM" id="PRENOM" >
                                   <font color="red" id="error_prenom"></font>
                            </div>
                            <div class="form-group">
                                <input type="number" autocomplete="false" class="form-control" placeholder="Tél"  onchange="check_tel(this.value)" name="TELEPHONE"  id="TELEPHONE">
                                   <font color="red" id="error_tel"></font>
                            </div>
                            <div class="form-group">
                                <input type="email" autocomplete="false" class="form-control" placeholder="E-mail" name="EMAIL" onchange="check_mail(this.value)"  id="EMAIL">
                                <font color="red" id="error_mail"></font>
                            </div>
                          
                            <div class="form-group">
                                <input type="password" autocomplete="false" class="form-control" placeholder="Mot de passe" name="PSWD" id="PSWD">
                                 <font color="red"   id="error_pswd"></font>
                            </div>
                            <div class="form-group">
                                <input type="password" autocomplete="false" class="form-control" placeholder="Confirmer le mot de passe" name="CPSWD" id="CPSWD" >
                               <font color="red"><?php echo form_error('CPSWD'); ?></font>
                            </div>

                              <div class="form-group">
                              
                            <div class="row" align="center">
                                <label class="radio-inline"><input type="radio" id="radio" value="M" name="SEXE" checked>Masculin</label>
                                <label class="radio-inline"><input value="F" type="radio" id="radio" name="SEXE">Féminin</label>
                             
                            </div>
                            </div>


                            <div class="form-group">
                                <label>
                                    <input type="checkbox" id="condition"   name="name" >
                                 
                                Je suis d'accord avec le terme et les conditions</label>
                                <font color="red" id="error_cond"><?php echo form_error('CPSWD'); ?></font>
                            </div>
                           
                        </form>
                         <div class="form-group">
                                <button onclick="envoi()" >S'inscrire</button>



                            </div>
                    </div>

<!--  -->


                </div>
            </div>




       
        </div>
    </section>
    <!-- Popular Listing -->


 
                       
    <!-- Most visited places -->
    <section id="post-visited-places">


        <div class="container over-hide">

            <div class="row">
                <div class="col-md-12 heading text-center">
                    <h2>Touvez <span>vos sejour préférés</span> sur notre plate forme!!</h2>
                   
                </div>
            </div>

            <div class="row" id="choix">
                <div id="places-slider" class="owl-carousel owl-theme">
<?php
 $i=0;
 $categories=array(); 
 foreach ($hotels as $key) {
   
 $photo=$this->Model->getOne('photo_hotel',array('ID_HOTEL'=>$key['HOTEL_ID']));
   $i++;
  $hot=$key['HOTEL_ID'];

?>

<div class="item">
                        <div class="popular-listing-box">
                            <div class="popular-listing-img" onclick="show_image('<?=$i?>','<?=$hot?>',1)">
                                <figure class="effect-ming"> <img   style="height:280px " src="<?php echo base_url() ?><?=$photo['PATH_PHOTO']?>" alt="image">
                                    <figcaption>
                                        <input value="<?php echo base_url() ?><?=$photo['PATH_PHOTO']?>" type="hidden" id="imgrcx<?=$i?>"  >
                                        <input value="<?=$key['ACCOMMODATION_NAME']?>" type="hidden" id="title<?=$i?>"  >
                                       <!--  <ul>
                                            <li onclick="alert()"><a data-toggle="modal" data-target="#myModal<?=$i?>" href="#"><i class="fa fa-sign-in" aria-hidden="true"></i></a>
                                            </li>
                                            
                                        </ul> -->
                                    </figcaption>
                                </figure>
                            </div>

                            <div class="popular-listing-detail">
                                <h3><a onclick="show_image('<?=$i?>','1')"><?=$key['ACCOMMODATION_NAME']?></a></h3>
                                 
                                 <div class="row">
                                  <!-- <div class="col-md-6">
                      &emsp;Nombre:&emsp;
                      <input class="form-text" style="width: 100px" id="qte<?=$i?>" type="number" value="1" min="1">
                      <input type="hidden" name="" id="choix<?=$i?>" value="<?=$key['HOTEL_ID']?>" >
                    </div><div class="col-md-6">Chambre
                      <select class="form-text">
                        <option value="">Choisir </option>
                        <option value="1">Petit</option>
                        <option value="2">Moyen </option> 
                        <option value="2">Double </option> 
                      </select></div><hr> -->
                         <a  href="<?=base_url()?>Home/detail/<?=$key['HOTEL_ID']?>"  class="btn btn-my"> <i class="fa fa-hotel"></i>  &emsp;Faire une réservation</a>
                    </div> 
                            </div>
                      
                            <ul class="place-listing-add">


<?php   
$tot_rat=$this->Model->getRequeteOne("SELECT SUM(RATING) as nb FROM rating_hotels WHERE HOTEL_ID=".$key['HOTEL_ID']." ");
$som=$this->Model->getRequeteOne("SELECT SUM(RATING) as nb FROM rating_hotels WHERE HOTEL_ID=".$key['HOTEL_ID']." ");

$tag=$this->Model->getRequeteOne("SELECT COUNT(*)  as nb FROM rating_hotels");
if($tag['nb']>0){
$moy=$som['nb']/ (5 * $tag['nb']);
}else{
 $moy=0; 
}
?>
                                <li>(<?=!empty($tot_rat['nb'])?$tot_rat['nb']:0?> Avis) </li>

                                <li id="myrate<?=$i?>">

                                 <?php 

                                
                                  $values=$this->Model->getOne("rating_hotels",array('USER_ID'=>$this->session->userdata('USER_ID'),'HOTEL_ID'=>$key['HOTEL_ID']));
                                  $rate="";
                                  for ($j=1; $j <= 5; $j++) { 

                                    $class=$j<=$moy? "checked" : "";
                                    $rate.='<a data-toggle="popover'.$i.''.$j.'" title="Rate"  onclick="show_image('.$i.','.$key['HOTEL_ID'].')"> <span class="fa fa-star '.$class.'"   ></span></a>';
                                   } 
                                   echo $rate;

                                  ?>                             
                                </li>
                                 <style type="text/css">.checked {
                                      color: orange;
                                    }</style>
                                <li>

                                    <?php 
                                      // $us=!empty($this->session->userdata('USER_ID'))? $this->session->userdata('USER_ID'):0;

                                    $likes=$this->Model->getRequeteOne('SELECT COUNT(*) as nb_lk FROM likes_hotels WHERE HOTEL_ID='.$key['HOTEL_ID'].' ');  ?>
                                    <input type="hidden" id="like_value<?=$key['HOTEL_ID']?>" value="<?=$likes['nb_lk']?>">
                                    <a data-toggle="popover" title="Like"  onclick="show_image('<?=$i?>','<?=$key['HOTEL_ID']?>')"><i class="fa fa-heart-o checked"  aria-hidden="true"></i><sup><span class="badge badge-warning checked"  id="like<?=$key['HOTEL_ID']?>"><?=$likes['nb_lk']!=0 ? $likes['nb_lk']:''?></span></sup></a>
                                </li>
                                <li>
                              <?php
$android = stripos($_SERVER['HTTP_USER_AGENT'], "android");
$iphone = stripos($_SERVER['HTTP_USER_AGENT'], "iphone");
$ipad = stripos($_SERVER['HTTP_USER_AGENT'], "ipad");
$link=base_url()."Home";
if($android !== false || $ipad !== false || $iphone !== false) {//For mobile
   ?>
  <a target="_blank" href="https://api.whatsapp.com/send?l=en&text=<?=$link?>"><i class="fa fa-share-alt checked" aria-hidden="true" data-toggle="popo" title="Share"></i></a>
   <?php
} else {//For desktop
   ?>

  
<a target="_blank" href="https://web.whatsapp.com/send?l=en&text=<?=$link?>"><i class="fa fa-share-alt checked" aria-hidden="true" data-toggle="popo" title="Share"></i></a>
   <?php
}
      ?>

                                </li>
                            </ul>

                        </div>
                   
                    </div>
           


          <?php
          }
          ?>                  

      

                </div>
            </div>
        </div>


<div id="alert" class="modal fade">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
               <center><h4 class="modal-title" id="title"></h4></center> 
            </div>
            <div class="modal-body">
                <img id="validate" src="">
  
            </div>
        </div>
    </div>
</div>


<div id="alert_image" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header btn-my">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
               <center><h3 class="modal-title" id="title_image">Faire une réservation</h3></center> 
            </div>
  
            <div class="modal-body row">
  <div class="col-md-12">
    <div class="well well-sm">
            <div class="text-right">
                <a class="btn btn-success btn-my" href="#reviews-anchor" id="open-review-box">Laisser un avis</a>
            </div>
        
            <div class="row" id="post-review-box" style="display:none;">
                   <form accept-charset="UTF-8" action="<?=base_url()?>Home/Add_Rating" method="post" id="myrate">
                       
                <div class="col-md-12">
                        <input id="ratings-hidden" name="rating" type="hidden"> 
                        <input id="HOTEL_ID" name="HOTEL_ID" type="hidden">
                        <div class="col-md-8">
                          <div class="stars starrr" data-rating="0">Votre notation&emsp;&emsp;</div>
                         </div>
                         <div class="col-md-4 text-right"> <a class="btn btn-danger btn-sm" href="#" id="close-review-box" style="display:none;">
                            <span class="glyphicon glyphicon-remove"></span></a></div>

                          <div class="row">
                            <div class="col-md-8">
                           <select class="form-control">
                           <option value="">J'ai pas aimé la chambre</option>
                           <option value="">La connexion est faible</option>
                           <option value="">Pas de papier hygiénique</option>

                           </select> <hr></div>
                        <div class="col-md-8">  <textarea class="form-control animated" cols="50" id="new-review" name="comment" placeholder="Entrez votre avis ici ..." rows="1" required=""></textarea></div>
                      
                         <div class=" col-sm-4">
                        
                        
                        <div class="text-right">                         
                           <?php if(!empty($this->session->userdata('USER_ID'))){  ?>
                            <button class="btn btn-my btn-lg" type="submit"  >Enregitrer</button>
                          <?php }else{?><button class="btn btn-my btn-lg" type="button"  onclick="info()" >Enregitrer</button><?php } ?>
                        </div>
                        </div></div>
                    
                </div>
                </form>
            </div>
        </div> 
         
   
  </div>            
<div class="col-md-6"><img id="validate_image" src=""></div>   
<div class="col-md-6">

        <h4>Répartition des notations</h4>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">5 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-success" role="progressbar" id="cinq" aria-valuenow="5" aria-valuemin="0" aria-valuemax="5" style="width: 50%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
         <!--  <div class="pull-right" style="margin-left:10px;">1</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">4 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="5" id="quatre" style="width: 80%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
          <!-- <div class="pull-right" style="margin-left:10px;">1</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">3 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="3" aria-valuemin="0" aria-valuemax="5" id="trois" style="width: 60%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
         <!--  <div class="pull-right" style="margin-left:10px;">0</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">2 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="2" aria-valuemin="0" aria-valuemax="5" id="deux" style="width: 40%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
        <!--   <div class="pull-right" style="margin-left:10px;">0</div> -->
        </div>
        <div class="pull-left">
          <div class="pull-left" style="width:35px; line-height:1;">
            <div style="height:9px; margin:5px 0;">1 <span class="glyphicon glyphicon-star"></span></div>
          </div>
          <div class="pull-left" style="width:180px;">
            <div class="progress" style="height:9px; margin:8px 0;">
              <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="5" id="un" style="width: 20%">
              <span class="sr-only">80% Complete (danger)</span>
              </div>
            </div>
          </div>
          <!-- <div class="pull-right" style="margin-left:10px;">0</div> -->
        </div>
      </div>      
  
<div class="col-sm-6">
        <div class="rating-block">
          <h4>Note moyenne des utilisateurs</h4>
          <h2 class="bold padding-bottom-7"><font id="total"></font> <small>/ 5</small></h2>
         
          <!--  btn btn-warning btn-sm-->
          <button type="button" id="star1" class="btn-default btn-grey " aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button" id="star2" class=" btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button"id="star3"  class="btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button" id="star4" class="btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button type="button" id="star5" class="btn-default btn-grey" aria-label="Left Align">
            <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
          </button>
          <button class="btn btn-my" onclick="do_like($('#HOTEL_ID').val())"><font id="aime">J'aime </font> <i class="fa fa-thumbs-o-up"></i></button>
     
        </div>
      </div>


</div>
  

<div class="modal-footer">
  <ul class="listing-amenities">
    <input type="hidden" id="id_hotel">
       
          <li><input type="submit" onclick="reserver()" class="btn btn-my" value="Vérfier la disponibilité"></li>
          </ul> 
          <button type="button" class="btn btn-danger" data-dismiss="modal">x</button>
         </div>

            </div>
        </div>
    
</div>

<div id="view" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header btn-my">
            <button type="button btn-danger" class="close" data-dismiss="modal" aria-hidden="true">×</button>
               <center><h3 class="modal-title" >Hors connexion</h3></center> 
            </div>
            <div class="modal-body ">
               Connectez vous ou abonnez vous à sur notre plateforme
              <br>
                <center> <a  class="btn btn-my" href="<?=base_url()?>Home/Login_Register" >
                  <font style="width: 100%">Connexion su la plate forme</font></a></center>
              
            </div>
        </div>
    </div>
</div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center discover">
                    <h2>
                   <span style="color: green">Logistique Covid est la pour votre service</span></h2>
                   <!--  <a href="#">Buy Now</a> -->
                </div>
            </div>

        </div>

    </section>
    <!-- Most visited places -->


<!-- Counter Section -->

  

    <div id="counter-section">
        <div class="container">

            <div class="row number-counters text-center">

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <!-- first count item -->
                    <div class="counters-item">
                        <i class="fa fa-file" aria-hidden="true"></i>
                        <!-- Set Your Number here. i,e. data-to="56" -->
                        <strong data-to="">0</strong>
                        <p>hôtel</p>
                        <div class="border-inner"></div>
                    </div>

                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <!-- first count item -->
                    <div class="counters-item">
                        <i class="fa fa-users" aria-hidden="true"></i>
                        <!-- Set Your Number here. i,e. data-to="56" -->
                        <strong data-to="0">0</strong>
                        <p>Abonnées</p>
                        <div class="border-inner"></div>
                    </div>

                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <!-- first count item -->
                    <div class="counters-item">
                        <i class="fa fa-th" aria-hidden="true"></i>
                        <!-- Set Your Number here. i,e. data-to="56" -->
                        <strong data-to="4">0</strong>
                        <p>Categories</p>
                        <div class="border-inner"></div>
                    </div>

                </div>

                <div class="col-md-3 col-sm-6 col-xs-12">
                    <!-- first count item -->
                    <div class="counters-item">
                        <i class="fa fa-th-list" aria-hidden="true"></i>
                        <!-- Set Your Number here. i,e. data-to="56" -->
                        <strong data-to="0">0</strong>
                        <p>Plats</p>
                        <div class="border-inner"></div>
                    </div>

                </div>

            </div>

        </div>
    </div>
    <!-- Counter Section -->
    

    <!-- Latest News -->
    <section id="our-blog" class="p_t70 p_b70">
        <div class="container">

            <div class="row">

                <div class="col-md-8 col-sm-8 col-xs-12">

                    <div class="row">
                        <div class="col-md-12 heading">
                            <h2>Hotel <span>News</span></h2>
                        </div>
                    </div>

                    <div id="latest_news-slider" class="owl-carousel owl-theme">

                       
                    </div>



                </div>

                <div class="col-md-4 col-sm-4 col-xs-12">

                    <div class="row">
                        <div class="col-md-12 heading">
                            <h2>Keep up  <span>to date</span>  </h2>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="updates">
                                <div class="over_image"><img src="<?php echo base_url() ?>front/images/update_bg.png" alt="image" />
                                </div>

                                <p class="p_b20">Abonnez-vous à nos newsletters pour recevoir les dernières nouvelles et mises à jour</p>
                                <form class="p-t-25" action="<?=base_url()?>Home/submit">
                                    <div class="col-md-12">
                                        <input type="text" name="NOM" placeholder="Name" >
                                    </div>
                                    <div class="col-md-10">
                                        <input type="email" class="email" placeholder="Email" >
                                    </div>
                                    <div class="col-md-2">
                                        <input type="submit" class="submit" value="">
                                        <span><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i></a></span>
                                    </div>
                                </form>
                            </div>
                        </div>

                    </div>
                </div>

            </div>

        </div>
    </section>
    <!-- Latest News -->

   
    <!-- Useer -->








    <!-- Footer -->
       <?php
       include 'includes/footer_front.php';
        ?>
    <!-- Footer -->

    <!-- Popups -->
       <?php
       include 'includes/popups_front.php';
        ?>

    <!-- Popups -->

</body>

<script type="text/javascript">
  function reserver(hotel) {
  window.location.replace('<?=base_url()?>Home/detail/'+hotel);
 }
</script>
<script >

     $(document).ready(function () {
   
    if($('#key_resto').val()!=''){     
    $('#HOTEL_ID').attr('disabled', 'disabled');
    }else{
    $('#HOTEL_ID').removeAttr('disabled');
   
  }      
load_carte();
$('.float').show();

$('#key').on("keyup input", function(){
        /* Get input value on change */
        var inputVal = $(this).val();
        var resultDropdown = $(this).siblings(".result");
        if(inputVal.length){
            $.post("<?=base_url()?>Home/Recherche", {term: inputVal}).done(function(data){
           
                resultDropdown.html(data);
            });
        } else{
            resultDropdown.empty();
            resultDropdown.html('');
        } 
    });
});

function detail(hotel) {
  var form = document.createElement("form");
   document.body.appendChild(form);
   form.method = "POST";
   form.action = "<?=base_url()?>Home/detail_hotel";
   var id_hotel = document.createElement("INPUT");         
    id_hotel.name="HOTEL_ID"
    id_hotel.value = hotel;
    id_hotel.type = 'hidden'
    form.appendChild(element1);    
    form.submit();
}
function serach_resto(id,type) {
   
      window.location.replace('<?=base_url()?>Home/index/'+id+'/'+type);    
  
  
}
function resto(id) {
    if(id!=''){
      window.location.replace('<?=base_url()?>Home/detail/'+id);    
    }
  
}
function categorie(id) {
   
}
function remove_fx(id) {
 var rowid=$('#rowid'+id).val();
  $.post('<?php echo base_url();?>Home/remove_carte',
        {
        rowid:rowid,  
        },
        function(data)
        {
        
          $('#data_carte').val('');
         data_carte.innerHTML = data;
        $('#data_carte').html(data);
        
         }
      );
}


function update(id,qte) {
var rowid=$('#rowid'+id).val();
  if(qte>=1){
  $.post('<?php echo base_url();?>Home/update_carte',
        {
        rowid:rowid,qte:qte,  
        },
        function(data)
        {
    
          $('#data_carte').val('');
         data_carte.innerHTML = data;
        $('#data_carte').html(data);
        
         }
      );
}
}

   function add_carte(i) {
      // $('#ModalLogin').modal();
    var QTE=$('#qte'+i).val();
    var HOTEL_ID=$('#choix'+i).val();
    window.location.replace('<?=base_url()?>Home/detail/'+HOTEL_ID);
}

function add_rating_resto(i,id)
{

 $('#alert_resto').modal({
  backdrop: false
})
  $('#title_resto').html($('#title_resto'+i).val());

 document.getElementById('resto_image').src =  $('#imgrc_resto'+i).val(); 
 document.getElementById('resto_id').value =id;

 $.post('<?=base_url()?>Home/Get_Rate_Resto',{id:id},function (data) {
  
  var resultat=data.split('#');
  $('#totalr').html(resultat[0]);
   $('#unr').css({'width':resultat[1]+'%','transition': 'width 2s'});
   $('#deuxr').css({'width':resultat[2]+'%','transition': 'width 2s'});
   $('#troisr').css({'width':resultat[3]+'%','transition': 'width 2s'});
   $('#quatrer').css({'width':resultat[4]+'%','transition': 'width 2s'});
   $('#cinqr').css({'width':resultat[5]+'%','transition': 'width 2s'});
    
    if(resultat[6]=='0'){
  $('#aimer').html("J'aime")
  }else{
  $('#aimer').html("Je n'aime plus");
 }
for (var i = 1; i <=5; i++) {
   if(i<=resultat[0]){
    document.getElementById('rstar'+i).setAttribute("class","btn-warning");
  }
 
}
 });
 




}
function show_image(i,hotel,id) {

 $('#alert_image').modal({
  backdrop: false
})
  $('#title_image').html($('#title'+i).val());
  $('#id_chambre').val(id);
  $('#id_hotel').val(hotel);

 document.getElementById('validate_image').src =$('#imgrcc'+i).val(); 
 document.getElementById('id_chambre').value =id;

 $.post('<?=base_url()?>Home/Get_Rate',{id:id},function (data) {
  
  var resultat=data.split('#');
  $('#total').html(resultat[0]);
   $('#un').css({'width':resultat[1]+'%','transition': 'width 2s'});
   $('#deux').css({'width':resultat[2]+'%','transition': 'width 2s'});
   $('#trois').css({'width':resultat[3]+'%','transition': 'width 2s'});
   $('#quatre').css({'width':resultat[4]+'%','transition': 'width 2s'});
   $('#cinq').css({'width':resultat[5]+'%','transition': 'width 2s'});
    
    if(resultat[6]=='0'){
  $('#aime').html("J'aime")
  }else{
  $('#aime').html("Je n'aime plus");
 }
for (var i = 1; i <=5; i++) {
   if(i<=resultat[0]){
    document.getElementById('star'+i).setAttribute("class","btn-warning");
  }
 
}
 });
 




}

function info() {
 $("#view").modal('show');
}

</script>
<script type="text/javascript">
   
    var  unic_phone=1; 
    var  unic_mail=1;
  function envoi(){ 
    
    var nom=$('#NOM').val().trim();
    var prenom=$('#PRENOM').val().trim();
    var tel= $('#TELEPHONE').val().trim();
    var email= $('#EMAIL').val().trim();
    

    var psw= $('#PSWD').val();
    var cpswd= $('#CPSWD').val();

    var ok_nom=0;
    var ok_prenom=0;
    var ok_tel= 0;
    var ok_mail= 0;
    var ok_pass=0;
    var valid_pass=0;
    var valid_cond=0;

//alert($("#radio:checked").val());
   if(nom==''){
    ok_nom=0;
    $('#error_nom').html('Champ obligatoire');
   }else{
    ok_nom=1;
    $('#error_nom').html('');
   }

   if(psw==''){
    ok_pass=0;
    $('#error_pswd').html('Champ obligatoire');
   }else{
    if(psw.length<4){
    ok_pass=0;
    $('#error_pswd').html('Mot de passe faible');
    }else{

    ok_pass=1;
    $('#error_pswd').html('');  
    }
   }


   if(prenom==''){
    ok_prenom=0;
    $('#error_prenom').html('Champ obligatoire');
   }else{
    ok_prenom=1;
    $('#error_prenom').html('');
   }



   
    if(tel==''){
    ok_tel=0;
    $('#error_tel').html('Champ obligatoire');
   }else{
    ok_tel=1;
    $('#error_tel').html('');
   }
  

   if(email==''){
    ok_mail=0;
    $('#error_mail').html('Champ obligatoire');
   }else{
    ok_mail=1;
    $('#error_mail').html('');
   }
 

 if(psw.localeCompare(cpswd)!=0){
    valid_pass=0;
    $('#error_pswd').html('Mot de passe non comforme');
    $('#PSWD').html('');
    $('#CPSWD').html('');
   }else{
    valid_pass=1;
    $('#valid_pass').html('');
   }




//alert( ok_nom +'-----'+ ok_prenom +'-----'+ ok_tel +'-----'+ unic_mail  +'-----'+ unic_phone );
 if( ok_nom && ok_prenom && ok_tel && unic_mail   && unic_phone && ok_pass && valid_pass ){ 
  
  var x=$("#condition").is(":checked");
  if(x==false){
    valid_cond=0;
    $('#error_cond').html('Accepeter nos condition');
   }else{
    valid_cond=1;
    $('#error_cond').html('');
   }
if(valid_cond){
   mysingup.submit();   
}

    
    }else{
        check_tel(tel);
        check_mail(email);
    }

}
function  check_tel(val){
                var value=val.trim();
                if(value!=''){
                var champ='TELEPHONE';
                    $.post('<?php echo base_url();?>Home/Is_Unic/',
                  {
                    value:value,champ:champ,
                    
                    },
                    function(data) 
                    { 
                     if(data==0){
                      unic_phone=0;
                      $('#error_tel').html('Tél existe_deja');
                     }else{
                      unic_phone=1;
                       $('#error_tel').html('');
                     }
                    }

                    );

                  }  
               }

                function  check_mail(val){
                var value=val.trim();
             if(value!=''){
                var champ='EMAIL';
                var valides= /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

                    $.post('<?php echo base_url();?>Home/Is_Unic/',
                  {
                    value:value,champ:champ,
                    
                    },
                    function(data) 
                    { 
                     if(data==0 ){
                      unic_mail=0;
                      $('#error_mail').html('Email existe eja');
                     }else if(!value.match(valides)){
                       $('#error_mail').html('Email est invalide');
                        unic_mail=0;
                     }
                     else{
                      unic_mail=1;
                       $('#error_mail').html('');
                     }
                    });
                        }         }

               
</script>

<script>
    
    function do_search() {
      
    var KEY=$('#key').val();
  
    var ok=0;
   
   if(KEY==''){
    ok=0;
    $('#error_search').html('Entre votre clef ...');
   }else{
    ok=1;
    $('#error_search').html('');
   }
  
   
                if(ok){
                
                mysearch.submit();

                  }  
    }

  function do_like_resto(id) {
if('<?=$this->session->userdata("USER_ID")?>'!=''){
        //var like=$('#like_value'+id).val();
          
        var resto=id; 
        //$('#like'+id).html(like);
       
        $.post('<?php echo base_url();?>Home/add_like_resto/',
          {    id:resto,
                    
          },
           function(data) 
            {
             // $('#like'+id).html(data);
              window.location.replace('<?=base_url()?>Home/#directory-category');
               $("#alert_resto").modal('hide');  
            }
            );

    }else{
        info();
    }
  }
    function do_like(id) {

        if('<?=$this->session->userdata("USER_ID")?>'!=''){
        var like=$('#like_value'+id).val();
          
        var id_plat=id; 
        //$('#like'+id).html(like);
       
        $.post('<?php echo base_url();?>Home/add_like/',
          {    id:id_plat,
                    
          },
           function(data) 
            {
              $('#like'+id).html(data);
              window.location.replace('<?=base_url()?>Home/#choix');
               $("#alert_image").modal('hide');  
            }
            );

    }else{
        info();
    }
       
    }

    function add_rating() {
    if('<?=$this->session->userdata("USER_ID")?>'!=''){
        myrate.submit();
        }else{
            info();
        }
    }

     function add_rating_cat(i,j,id) {
    if('<?=$this->session->userdata("USER_ID")?>'!=''){
     $.post('<?php echo base_url();?>Home/rating_chambre/',
          { 
             id:id,i:i,j:j,      
          },
           function(data) 
            {
              
             $('#catrate'+i).html(data); 

            }
            );
           }else{
            info();
           }
    }


</script>

<script type="text/javascript">
  
function load_carte() {
 
}
$(function(){

  $('#new-review').autosize({append: "\n"});

  var reviewBox = $('#post-review-box');
  var newReview = $('#new-review');
  var openReviewBtn = $('#open-review-box');
  var closeReviewBtn = $('#close-review-box');
  var ratingsField = $('#ratings-hidden');

  openReviewBtn.click(function(e)
  {
    reviewBox.slideDown(400, function()
      {
        $('#new-review').trigger('autosize.resize');
        newReview.focus();
      });
    openReviewBtn.fadeOut(100);
    closeReviewBtn.show();
  });

  closeReviewBtn.click(function(e)
  {
    e.preventDefault();
    reviewBox.slideUp(300, function()
      {
        newReview.focus();
        openReviewBtn.fadeIn(200);
      });
    closeReviewBtn.hide();
    
  });

  $('.starrr').on('starrr:change', function(e, value){
    ratingsField.val(value);
  });
});
</script>

<script type="text/javascript">
  

$(function(){

  $('#resto-review').autosize({append: "\n"});

  var reviewBox = $('#post-review-resto');
  var newReview = $('#resto-review');
  var openReviewBtn = $('#open-review-resto');
  var closeReviewBtn = $('#close-review-resto');
  var ratingsField = $('#ratings-hidden-resto');

  openReviewBtn.click(function(e)
  {
    reviewBox.slideDown(400, function()
      {
        $('#resto-review').trigger('autosize.resize');
        newReview.focus();
      });
    openReviewBtn.fadeOut(100);
    closeReviewBtn.show();
  });

  closeReviewBtn.click(function(e)
  {
    e.preventDefault();
    reviewBox.slideUp(300, function()
      {
        newReview.focus();
        openReviewBtn.fadeIn(200);
      });
    closeReviewBtn.hide();
    
  });

  $('#star-resto').on('starrr:change', function(e, value){
    ratingsField.val(value);
  });
});
</script>

<script type="text/javascript">
function showresponddiv(messagedivid){
   
    if (document.getElementById(messagedivid).style.display=="none"){
        document.getElementById(messagedivid).style.display="inline";
        document.getElementById("unpub").style.display="none";
       
    } else {
        document.getElementById(messagedivid).style.display="none";
        document.getElementById("unpub").style.display="inline";
      

    }
}
</script> 
</html>